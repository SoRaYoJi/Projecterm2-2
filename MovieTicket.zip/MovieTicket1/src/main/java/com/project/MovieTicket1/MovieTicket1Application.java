package com.project.MovieTicket1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieTicket1Application {

	public static void main(String[] args) {
		SpringApplication.run(MovieTicket1Application.class, args);
	}

}
