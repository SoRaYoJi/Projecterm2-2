package com.project.MovieTicket1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/")
    public String home() {
        return "index"; // ชี้ไปยังไฟล์ index.jsp ในโฟลเดอร์ /WEB-INF/views/
    }

    @GetMapping("/cinema")
    public String cinema() {
        return "cinema"; // ชี้ไปยังไฟล์ cinema.jsp ในโฟลเดอร์ /WEB-INF/views/
    }

    @GetMapping("/promotion")
    public String promotion() {
        return "promotion"; // ชี้ไปยังไฟล์ promotion.jsp ในโฟลเดอร์ /WEB-INF/views/
    }
}

