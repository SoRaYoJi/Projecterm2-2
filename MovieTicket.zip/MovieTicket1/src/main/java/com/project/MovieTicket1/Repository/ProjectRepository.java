package com.project.MovieTicket1.Repository;

import com.project.MovieTicket1.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectRepository extends JpaRepository<User, Long> {
}
