package com.project.MovieTicket.Repository;

import com.project.MovieTicket.Model.MovieModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MovieRepository extends JpaRepository<MovieModel, Long> {

    MovieModel findByTitle(String moviename); // ค้นหาภาพยนตร์จากชื่อ

    List<MovieModel> findByTitleContaining(String moviename); // ค้นหาภาพยนตร์จากชื่อที่มีคำที่ต้องการค้นหา
}