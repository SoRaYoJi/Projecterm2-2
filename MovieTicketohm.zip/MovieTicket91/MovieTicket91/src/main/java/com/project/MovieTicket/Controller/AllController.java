package com.project.MovieTicket.Controller;

import com.project.MovieTicket.Model.MovieModel;
import com.project.MovieTicket.Service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.List;

@Controller
public class AllController {

    @Autowired
    private MovieService movieService;

    @RequestMapping("/home")
    public String showHomePage() {
        return "home"; // หน้า home.jsp
    }

    // แสดงรายการภาพยนตร์ทั้งหมด หรือค้นหา
    @RequestMapping("/movies")
    public String showMoviesPage(@RequestParam(value = "query", required = false) String query, Model model) {
        List<MovieModel> movies;

        if (query != null && !query.isEmpty()) {
            movies = movieService.searchMoviesByTitle(query); // ค้นหาตามชื่อ
        } else {
            movies = movieService.getAllController(); // ดึงรายการทั้งหมด
        }

        model.addAttribute("movies", movies);
        model.addAttribute("searchQuery", query); // ส่งค่าคำค้นหาไปยัง View
        return "movies";  // หน้า movies.html หรือ movies.jsp
    }

    @GetMapping("/cinema")
    public String cinemaPage(Model model) {
        model.addAttribute("movieName", "GHOSTBUSTERS"); // ตัวอย่างค่าตัวแปร
        return "cinema"; // ชื่อไฟล์ cinema.jsp
    }

    @RequestMapping("/promotion")
    public String showPromotionPage() {
        return "promotion";  // หน้า promotion.jsp
    }

    @RequestMapping("/seat")
    public String showSeatPage() {
        return "seat";  // หน้า seat.jsp
    }

    @RequestMapping("/buyticket")
    public String showBuyticketPage() {
        return "buyticket";  // หน้า seat.jsp
    }

    @GetMapping("/seat")
    public String seatPage(Model model) {
        model.addAttribute("movieName", "GHOSTBUSTERS"); // ตัวอย่างค่าตัวแปร
        return "seat"; // ชื่อไฟล์ cinema.jsp
    }

    @RequestMapping("/profile")
    public String showProfilePage() {
        return "profile";  // หน้า promotion.jsp
    }

    @GetMapping("/buyticket")
    public String buyticketPage(Model model) {
        model.addAttribute("movieName", "GHOSTBUSTERS"); // ตัวอย่างค่าตัวแปร
        return "buyticket"; //
    }


    @GetMapping("/ticket")
    public String ticketPage(Model model) {
        model.addAttribute("movieName", "GHOSTBUSTERS"); // ตัวอย่างค่าตัวแปร
        return "ticket"; // ชื่อไฟล์ cinema.jsp
    }

    @GetMapping("/receipt")
    public String receiptPage(Model model) {
        model.addAttribute("movieName", "GHOSTBUSTERS"); // ตัวอย่างค่าตัวแปร
        return "receipt"; // ชื่อไฟล์ cinema.jsp
    }

    @RequestMapping("/receipt")
    public String showreceiptPage() {
        return "receipt";  // หน้า seat.jsp
    }
}

