package com.project.MovieTicket.Service;

import com.project.MovieTicket.Entity.Movie;
import com.project.MovieTicket.Repository.MovieRepository;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.List;

@Service
public class MovieService {

    private final MovieRepository movieRepository;

    public MovieService(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }

    public List<Movie> getAllMovies() {
        List<Movie> movies = movieRepository.findAll();

        for (Movie movie : movies) {
            if (movie.getImagePath() != null) {
                try {
                    // ตรวจสอบว่า imagePath เป็น null หรือไม่ และทำการแปลง Base64
                    String base64Image = Base64.getEncoder().encodeToString(movie.getImagePath());
                    movie.setBase64Image(base64Image);
                } catch (Exception e) {
                    // หากมีข้อผิดพลาดในการแปลงให้ log ข้อผิดพลาด
                    System.err.println("Error converting image to Base64 for movie: " + movie.getMoviename());
                    e.printStackTrace();
                }
            }
        }

        return movies;
    }
}
