package com.project.MovieTicket.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MovieController {

    @RequestMapping("/home")
    public String showHomePage() {
        return "home"; // หน้า home.jsp
    }

    @RequestMapping("/movies")
    public String showMoviesPage() {
        return "movies";  // หน้า movies.jsp
    }

    @GetMapping("/cinema")
    public String cinemaPage(Model model) {
        model.addAttribute("movieName", "GHOSTBUSTERS"); // ตัวอย่างค่าตัวแปร
        return "cinema"; // ชื่อไฟล์ cinema.jsp
    }

    @RequestMapping("/promotion")
    public String showPromotionPage() {
        return "promotion";  // หน้า promotion.jsp
    }

    @RequestMapping("/seat")
    public String showSeatPage() {
        return "seat";  // หน้า seat.jsp
    }

    @GetMapping("/seat")
    public String seatPage(Model model) {
        model.addAttribute("movieName", "GHOSTBUSTERS"); // ตัวอย่างค่าตัวแปร
        return "seat"; // ชื่อไฟล์ cinema.jsp
    }

    @RequestMapping("/profile")
    public String showProfilePage() {
        return "profile";  // หน้า promotion.jsp
    }
}
