package com.project.MovieTicket.Service;

import com.project.MovieTicket.Entity.Movie;
import com.project.MovieTicket.Repository.MovieRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieService {

    private final MovieRepository movieRepository;

    public MovieService(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }

    public List<Movie> getAllMovies() {
        return movieRepository.findAll();  // ส่ง path ของภาพโดยตรง
    }
}
