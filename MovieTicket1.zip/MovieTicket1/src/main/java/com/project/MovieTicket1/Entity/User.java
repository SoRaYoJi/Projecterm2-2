package com.project.MovieTicket1.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "userp") // ชื่อ Table ในฐานข้อมูล
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // id เพิ่มอัตโนมัติ
    private Long id;

    @Column(name = "user", nullable = false, unique = true) // ชื่อคอลัมน์เป็น 'user'
    private String username;

    @Column(name = "password", nullable = false) // ชื่อคอลัมน์เป็น 'password'
    private String password;

    // ฟิลด์อื่น ๆ เช่น role (หากต้องการ)
    @Column(nullable = false)
    private String role = "USER"; // ค่าเริ่มต้นเป็น USER

    // Getters และ Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
