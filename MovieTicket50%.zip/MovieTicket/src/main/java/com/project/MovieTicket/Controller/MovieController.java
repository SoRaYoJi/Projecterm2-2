package com.project.MovieTicket.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MovieController {

    @RequestMapping("/home")
    public String showHomePage() {
        return "home"; // หน้า home.jsp
    }

    @RequestMapping("/movies")
    public String showMoviesPage() {
        return "movies";  // หน้า movies.jsp
    }

    @RequestMapping("/cinema")
    public String showCinemaPage() {
        return "cinema";  // หน้า cinema.jsp
    }

    @RequestMapping("/promotion")
    public String showPromotionPage() {
        return "promotion";  // หน้า promotion.jsp
    }
}
