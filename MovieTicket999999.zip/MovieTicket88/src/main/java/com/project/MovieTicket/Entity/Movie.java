package com.project.MovieTicket.Entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "movies")
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int movieid;

    private String moviename;

    @Temporal(TemporalType.DATE)
    private Date releasedate;

    private String durationminutes;

    @Column(name = "image_path")
    private String imagePath;  // เปลี่ยนเป็น String เพื่อเก็บ path ของไฟล์ภาพ

    // Getters and Setters
    public int getMovieid() {
        return movieid;
    }

    public void setMovieid(int movieid) {
        this.movieid = movieid;
    }

    public String getMoviename() {
        return moviename;
    }

    public void setMoviename(String moviename) {
        this.moviename = moviename;
    }

    public Date getReleasedate() {
        return releasedate;
    }

    public void setReleasedate(Date releasedate) {
        this.releasedate = releasedate;
    }

    public String getDurationminutes() {
        return durationminutes;
    }

    public void setDurationminutes(String durationminutes) {
        this.durationminutes = durationminutes;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
