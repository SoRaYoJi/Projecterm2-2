//package com.project.MovieTicket.Model;
//
//import jakarta.persistence.*;
//import java.util.Date;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//
//@Entity
//public class MovieModel {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "movieid") // Mapping กับคอลัมน์ในฐานข้อมูล
//    private Long movieid;
//
//    private String moviename;
//
//    private int durationminutes;
//
//    @Column(name = "release_date") // Mapping กับคอลัมน์ในฐานข้อมูล
//    private Date releasedate;
//
//    @Column(name = "image_path") // Mapping กับคอลัมน์ในฐานข้อมูล
//    private String image_path;
//
//    // Getters and Setters
//    public Long getMovieId() {
//        return movieid;
//    }
//
//    public void setMovieId(Long movieid) {
//        this.movieid = movieid;
//    }
//
//    public String getTitle() {
//        return moviename;
//    }
//
//    public void setTitle(String moviename) {
//        this.moviename = moviename;
//    }
//
//    public Date getReleaseDate() {
//        return releasedate;
//    }
//
//    public void setReleaseDate(Date releasedate) {
//        this.releasedate = releasedate;
//    }
//
//    public int getDuration() {
//        return durationminutes;
//    }
//
//    public void setDuration(int durationminutes) {
//        this.durationminutes = durationminutes;
//    }
//
//
//
//    public String getImagePath() {
//        return image_path;
//    }
//
//    public void setImagePath(String image_path) {
//        this.image_path = image_path;
//    }
//}