//package com.project.MovieTicket.Repository;
//
//import com.project.MovieTicket.Model.Cinema;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface CinemaRepository extends JpaRepository<Cinema, Long> {
//    // สามารถเพิ่ม method สำหรับค้นหาต่างๆ ได้ที่นี่ เช่น ค้นหาตามชื่อ
//    Cinema findByName(String name);
//}
