//package com.project.MovieTicket.Entity;
//
//import jakarta.persistence.*;
//
//@Entity
//public class Cinema {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//    private String name;
//    private String location;
//    private int totalTheaters;
//
//    // Getters and Setters
//}
//
