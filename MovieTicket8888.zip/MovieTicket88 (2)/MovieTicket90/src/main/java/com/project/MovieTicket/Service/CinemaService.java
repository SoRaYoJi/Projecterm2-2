//package com.project.MovieTicket.Service;
//
//import com.project.MovieTicket.Model.Cinema;
//import com.project.MovieTicket.Repository.CinemaRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import java.util.Collections;
//import java.util.List;
//import java.util.stream.Collectors;
//
//@Service
//public class CinemaService {
//
//    @Autowired
//    private CinemaRepository cinemaRepository;
//
//    // ฟังก์ชันดึงข้อมูลโรงหนังทั้งหมด
//    public List<Cinema> getAllCinemas() {
//        return cinemaRepository.findAll(); // ดึงข้อมูลทั้งหมดจากฐานข้อมูล
//    }
//
//    // ฟังก์ชันค้นหาโรงหนังตามชื่อ
//    public Cinema getCinemaByName(String name) {
//        return cinemaRepository.findByName(name); // ค้นหาโรงหนังจากชื่อ
//    }
//
//    // ฟังก์ชันค้นหาโรงหนังที่มีชื่อคล้ายกับคำค้น
//    public List<Cinema> searchCinemasByName(String name) {
//        return cinemaRepository.findByNameContaining(name); // ค้นหาโรงหนังที่มีชื่อคล้ายกับคำค้น
//    }
//
//    // ฟังก์ชันสุ่มเลือกโรงหนัง n แห่ง
//    public List<Cinema> getRandomCinemas(int n) {
//        List<Cinema> allCinemas = cinemaRepository.findAll(); // ดึงข้อมูลโรงหนังทั้งหมด
//        Collections.shuffle(allCinemas); // สุ่มลำดับ
//        return allCinemas.stream() // ใช้ Stream API
//                .limit(n) // จำกัดจำนวนผลลัพธ์
//                .collect(Collectors.toList()); // รวมผลลัพธ์เป็น List
//    }
//}
