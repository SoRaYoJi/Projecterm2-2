//package com.project.MovieTicket.Model;
//
//import jakarta.persistence.*;
//import jakarta.persistence.Id;
//import jakarta.persistence.Entity;
//
//@Entity
//public class Cinema {
//
//    @Id
//    private Long id;  // ไอดีของโรงหนัง (Primary Key)
//    private String name;  // ชื่อโรงหนัง
//    private String location;  // ที่ตั้งของโรงหนัง
//    private int numberOfScreens;  // จำนวนจอในโรงหนัง
//
//    // Constructor (ถ้ามี)
//    public Cinema(Long id, String name, String location, int numberOfScreens) {
//        this.id = id;
//        this.name = name;
//        this.location = location;
//        this.numberOfScreens = numberOfScreens;
//    }
//
//    // Getter และ Setter
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getLocation() {
//        return location;
//    }
//
//    public void setLocation(String location) {
//        this.location = location;
//    }
//
//    public int getNumberOfScreens() {
//        return numberOfScreens;
//    }
//
//    public void setNumberOfScreens(int numberOfScreens) {
//        this.numberOfScreens = numberOfScreens;
//    }
//}
//
